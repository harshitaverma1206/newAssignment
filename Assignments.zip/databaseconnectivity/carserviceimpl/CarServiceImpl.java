package com.yash.carserviceimpl;
import com.yash.carmodel.CarModel;
import com.yash.service.CarService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



public class CarServiceImpl implements CarService {
   
	
	
	
	@Override
	public void getAllCar() {
		// TODO Auto-generated method stub
		
	}
	
	
		
		
		
		
	

	
	}
	
	}	

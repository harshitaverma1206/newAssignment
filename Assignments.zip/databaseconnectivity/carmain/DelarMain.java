package com.yash.carmain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.yash.carserviceimpl.CarServiceImpl;
import com.yash.carserviceimpl.DelarServiceImpl;

public class DelarMain extends DelarServiceImpl{
	
	static Logger logger=Logger.getLogger(CarServiceImpl.class);
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		
		System.out.println("Enter choice");
		System.out.println("insert record");
		System.out.println("update record");
		System.out.println("delete record");
		int choice = Integer.parseInt(sc.nextLine());
		switch(choice) {
		case 1:
			insertDelar();
			break;
			
		case 2:
			//update();
			break;
			
		case 3:
			//Delete();
			break;
		}
		
		}catch(Exception e) {
			System.out.println(e);
		}
		}
	 public static void insertDelar() throws SQLException {
		   Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		   String s="insert into delar1(reg_num,shop_name,owner_name)values(?,?,?)";
		   PreparedStatement st=con.prepareStatement(s);
		   st.setInt(1,reg_num);
		   st.setString(2,shop_name);
		   st.setString(3,owner_name);
		   st.execute();
		   System.out.println("record inserted successfully");
		   st.close();
		   		
		}
}
package com.yash.carmain;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.yash.carmodel.CarModel;
import com.yash.carserviceimpl.CarServiceImpl;

public class CarMain  {
	static Logger logger=Logger.getLogger(CarServiceImpl.class);
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		try {
		CarMain a=new CarMain();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		
		System.out.println("Enter choice");
		System.out.println("insert record");
		System.out.println("update record");
		System.out.println("delete record");
		int choice = Integer.parseInt(sc.nextLine());
		switch(choice) {
		case 1:
			insertRecord();
			break;
			
		case 2:
			update();
			break;
			
		case 3:
			Delete();
			break;
		}
		
		}catch(Exception e) {
			System.out.println(e);
		}
		}
	
		public static void insertRecord() throws ClassNotFoundException, SQLException {
			PropertyConfigurator.configure("C:\\Users\\harshita.verma\\Documents\\workspace-spring-tool-suite-4-4.11.0.RELEASE\\databaseconnectivity\\src\\Resourses\\log.properties1"); 
			System.out.println("inside insert record");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			
			String sql="insert into car1(registrationnum,name,engine,type)values(?,?,?,?)";
			PreparedStatement sta = con.prepareStatement(sql);
			
			sta.setInt(1,5);
			
			sta.setString(2,"andy");
			
			sta.setInt(3,2020);
			
			sta.setString(4,"maruti");
			int i=sta.executeUpdate();  
			logger.info(i+" records inserted");
			
		}
				
           public static void update() throws ClassNotFoundException, SQLException {
        	   Class.forName("com.mysql.cj.jdbc.Driver");
   			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
   			
        	   String sql1 = "UPDATE car1 SET registrationnum=?, name=?, engine=? WHERE type=?";
			 
			PreparedStatement statement = con.prepareStatement(sql1);
			statement.setInt(1,1);
			statement.setString(2, "Bill");
			statement.setInt(3,2017);
			statement.setString(4, "maruti");
			 
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
			    System.out.println("An existing user was updated successfully!");
			}
			}	
           public static void Delete() throws ClassNotFoundException, SQLException {
        	   Class.forName("com.mysql.cj.jdbc.Driver");
      			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
           String sql = "DELETE FROM car1 WHERE name=?";
           
           PreparedStatement statement = con.prepareStatement(sql);
           statement.setString(1, "jhon");
            
           int rowsDeleted = statement.executeUpdate();
           if (rowsDeleted > 0) {
               System.out.println("A user was deleted successfully!");
           }
	
           }
           }
           
		  
		
		 
	


                                                 assignments
Q.1 create a method to find the sum of the cubes of the digit of an n digit number.
ANS:
import java.util.*;
import java.io.*;

class Cubes {
public static void main(String args[]){
    int input=0;
    int num1,num2,num3;
    System.out.println("Enter a Number");
    Scanner console = new Scanner(System.in);
    input= Integer.parseInt(console.nextLine());
    int number = input; 
    int counter = 0; 
    while(number>0){
        int t= number%10;
        System.out.println("Cube of "+t +" is "+(t*t*t));
        counter = counter+1;
        number = number/10;

    }
  }
}

Q.2 write a java program that siulates a traffic light. the program lets the user select one 
of three lights:red,yellow or green with radio buttons.on entering the choice,an appropriate message 
with "stop" or "ready" or "go" should appear in console.initially there is no message shown.
ANS:-

import javax.swing.*;    
public class Valid {    
JFrame f;    
Valid(){    
f=new JFrame();     
JRadioButton r1=new JRadioButton("A) green");    
JRadioButton r2=new JRadioButton("B) yellow");  
JRadioButton r3=new JRadioButton("C) red");
r1.setBounds(75,50,100,30);    
r2.setBounds(75,100,100,30);
r3.setBounds(75,150,100,30);
ButtonGroup bg=new ButtonGroup();    
bg.add(r1);bg.add(r2);bg.add(r3);    
f.add(r1);f.add(r2);
f.add(r2);f.add(r3);
f.setSize(300,300);    
f.setLayout(null);    
f.setVisible(true);    
}    
public static void main(String[] args) {    
    new Valid();    
}    
}    



Q.3 the fibonnaci sequence is defiend by the following rule.
 the first 2 values in sequence are 1,1.
 every subsequent value is the sum of the 2 values preciding it .write a java progra that uses
 both recursive and non-recursive functions to print the  nth value of the fibonacci sequence

Q.4 write a java program that prompts the user for an integer and then prints out all the prime
   number up to the integer.
ANS:-
  import java.util.*;
class Prime
{
  public static void main(String args[])
 {
  int n,f;
  Scanner scr=new Scanner(System.in);
  System.out.println("\nEnter n value:  ");
  n=scr.nextInt();
  System.out.println("\nPrimenumbers are : ");
      for(int i=2;i<=n;i++)
         {
            f=0;
            for(int j=2;j<=i/2;j++)
            if((i%j)==0)
                {
                  f=1;
                  break;
                  }
                        if(f==0)
                        System.out.print(i+"   ");
            }
       }
}
   
Q.5 create a class with a method which can calculate the sum of 
    n natural number which are divisible by 3 or 5 

  import java.io.*;
 
  class sum {
public static int sum(int N)
{
    int S1, S2, S3;
 
    S1 = ((N / 3)) * (2 * 3 +
        (N / 3 - 1) * 3) / 2;
    S2 = ((N / 5)) * (2 * 5 +
        (N / 5 - 1) * 5) / 2;
    S3 = ((N / 15)) * (2 * 15 +
        (N / 15 - 1) * 15) / 2;
 
    return S1 + S2 - S3;
}
 

    public static void main (String[] args) {
int N = 20;
    System.out.println( sum(N));
    }
}
 
Q.6 create a class with a method to find the difference between the sum of the squares and the squares of 
   the sum of the first n natural number.
  

public class Sum{
 
static int Calculate_Diff(int n){
 
int l, k, m;
    
    l = (n * (n + 1) * (2 * n + 1)) / 6;
     
    
    k = (n * (n + 1)) / 2;
 
    
    k = k * k;
     
    
    m = Math.abs(l - k);
     
    return m;
 
}
 
public static void main(String s[])
{
    int n = 10;
    System.out.println(Calculate_Diff(n));    
     
}
}


Q.7 create a mathod to check if a number is an incresing number.  

import java.util.Scanner;

class  main{
    public static void main(String args[]) { 
       int num;
       boolean flag = false;
       Scanner SC = new Scanner(System.in);
        
       System.out.println("Enter a number : ");
       num = scanner.nextInt();
        
       int currentNum = num % 10;
       num = num/10;
        
       while(num>0){
           
           if(currentNum <= num % 10){
               flag = true;
               break;
           }

           currentNum = num % 10;
           num = num/10;
       }
               
       if(flag){
           System.out.println("Numbers are not in increasing order.");
       }else{
           System.out.println("Numbers are in increasing order.");
       }
    }
}

Q.8 create a mathod to check if a number is a power of two or not. 
 
import java.util.Scanner;

class  Valid{
    public static void main(String args[]) { 
       int num;
       Scanner SC = new Scanner(System.in);
        
       System.out.println("Enter a number : ");
       num = SC.nextInt();
           
           if(num%2==0){
              
           System.out.println("it is  a power of two.");}
       else{
           System.out.println("it is not a power of two");
       }
    }
} 

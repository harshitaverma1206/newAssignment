package com.yash.logdemo;


	import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.*;  
	import java.sql.SQLException;  
	import java.util.*;  
	
	class Add
	 {
	 	int c;
	 	void addition(int x,int y)
	 	{
	 	 c=x+y;
	 	}
		 
	 }	
	
	public class LogDemo {  
	   
	   static Logger log = Logger.getLogger(LogDemo.class.getName());  
	     
	   public static void main(String[] args)throws IOException,SQLException{  
	   PropertyConfigurator.configure("C:\\Users\\harshita.verma\\Documents\\workspace-spring-tool-suite-4-4.11.0.RELEASE\\logdemo\\prop\\c.properties");
		   
	      log.debug("Hello this is a debug message");  
	      System.out.println("this is:"+log);
	      System.out.println("this is for debug");
	       
	      try{
        	  int a=10;
	          int b=20;
	      Add r=new Add();
	      r.addition(a,b);
	      System.out.println("Addition of two numbers is : "+r.c);
	      
	      }
	      catch(Exception e) {
	    	  System.out.println(e);
	      }
	    	  
	      }
	   }   


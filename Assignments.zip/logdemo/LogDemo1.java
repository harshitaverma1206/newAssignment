package com.yash.logdemo;


	import org.apache.log4j.Logger;  
	  
	import java.io.*;  
	import java.sql.SQLException;  
	import java.util.*;  

		public class LogDemo1 {  
	   
	   static Logger log = Logger.getLogger(LogDemo.class.getName());  
	     
	   public static void main(String[] args)throws IOException,SQLException{  
		   
	      log.debug("Hello this is a debug message");  
	      log.info("Hello this is an info message");  
	      try{int num1 = 0, num2 = 0, sum;
	      sum = addTwo(num1, num2);
	      
	      }
	      catch(Exception e) {
	    	  System.out.println(e);
	      }
	    	  
	      }

	   public static int addTwo(int a, int b)
	   {
	      int sum = a + b;
	      return sum;
	   }
	   }   


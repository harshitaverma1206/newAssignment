package com.yash.logdemo;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LogDemo2 {
	public static void add() {
		System.out.println("Addition is:"+(10+30));
		
	}
	public static void sub() {
		System.out.println("Subtraction is:"+20/0);
	}
	static Logger logger=Logger.getLogger(LogDemo2.class);
	public static void main(String[]args) {
		PropertyConfigurator.configure("C:\\Users\\harshita.verma\\Documents\\workspace-spring-tool-suite-4-4.11.0.RELEASE\\logdemo\\src\\Resouses\\log.properties");
		try{logger.debug("debug");
		logger.warn("warn");
		logger.fatal("fatal");
		add();
		sub();}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}

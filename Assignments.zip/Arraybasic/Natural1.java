import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class Natural1 {

	@Test
	 
		public void sumtest() {
			Natural top=new Natural();
			int result=top.sum(15/5);
			assertEquals(3,result);
		
			
		}	
	}



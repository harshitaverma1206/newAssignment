import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ArrayTestClass {

	@Test
	public void sumtest() {
		ArrayTestClass top=new ArrayTestClass ();
		assertEquals(3,result bv);
	
		
	}	
		
			
		
	}

}

package com.yash.patterndemo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
public class Adhar {

	public static boolean isValidAdharNo(java.lang.String aadharNumber1) {
				java.lang.String regex="^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$";
				Pattern p=Pattern.compile(regex);
				if(aadharNumber1==null)
				{
					return false;
				}
				Matcher m=p.matcher(aadharNumber1);
				return m.matches();
				}
			
			
public static void main(String[]args) {
	java.lang.String aadharNumber1="3675 9834 6012";
	System.out.println(isValidAdharNo(aadharNumber1));
	java.lang.String aadharNumber2="3675 9834 6012 8";
	System.out.println(isValidAdharNo(aadharNumber2));
		}
	}
	
		


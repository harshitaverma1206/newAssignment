package com.yash.patterndemo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Landline {
	public static boolean isValidLandline(String LandlineNumber) {
		 
		
		String regex="^[0-11]{4}[-][0-9]{6,8}$";
		Pattern p=Pattern.compile(regex);
		if(LandlineNumber==null)
		{
			return false;
		}
		Matcher m=p.matcher(LandlineNumber);
		return m.matches();
		}
	
	
		public static void main(String[]args) {
			String LandlineNumber1="0755-2765426";
			System.out.println(isValidLandline(LandlineNumber1));
			String LandlineNumber2="0755-765426";
			System.out.println(isValidLandline(LandlineNumber2));
}
}




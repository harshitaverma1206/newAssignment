package com.yash.tdddeom.util;

public class Tdd1 {
		public void execute() {
		}

		public boolean isEvenNumber(int number){
	         
	        boolean result = false;
	        if(number%2 == 0){
	            result = true;
	        }
	        return result;
	    }
	}
	
	

	



package com.yash.tdddeom.util;

public class Tdd2 {
	public void execute() {
	}
	public boolean isoddNumber(int number) {
		     
	        boolean result = true;
	        if(number%2 == 0){
	            result = false;
	        }
	        return result;
	    }
	}



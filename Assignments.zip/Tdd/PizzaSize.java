package com.yash.tdddeom.util;

public enum PizzaSize {
SMAll(3),MEDIUM(5),LARGE(12);	
int size;
private PizzaSize(int size) {
	this.size=size;
	}
public int getSize() {
	return this.size;
}
}

package com.yash.tdddeom.util;
enum Hello{
	hiii,how,are,you,
}

public class Enum1 {
     Hello hello;
     
     public Enum1(Hello hello) {
    	 this.hello=hello;
     }
 public static void main(String args[]) {
	 System.out.println(Hello.hiii);
	 System.out.println(Hello.how);
	 System.out.println(Hello.are);
	 
 }    
}

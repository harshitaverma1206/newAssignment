package com.java.classdemos.test;

public class Calculator {
	public int add(int a,int b){
		return a+b;
	}
	public String Concat(String a,String b ){
		return a+b;	
	}

}

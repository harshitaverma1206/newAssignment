package Calculator1.java;

public class Calculator2 {
       int i;
       public int calculate(String string) {
    	   if(string=="")
    	   {
    		   i=0;
    	   }
    	   else if(string=="2")
    	   {
    		   i=2;
    	   }
    	   return i;
    	   
       }
       public int calculate(int j,int k) {
    	   return j+k;
       }
}

package com.yash.collection;

import java.util.HashSet;


class Shop{
	int id;
	String name;
	int price;

public Shop(int id ,String name  ,int price) {
	super();
	this.id=id;
	this.name=name;
	this.price=price;
}
public String toString() {
	return "Shop[id=" + id +",name="+name+",price="+price+"]";
}
}
public class Shooping {
	public static void main(String args[]) {
		
		HashSet<Shop> h = new HashSet<Shop>();
		  
        // Adding elements into HashSet using add()
       try { h.add(new Shop(1,"cloth",123));
             h.add(new Shop(2,"T-shirt",345));
             h.add(new Shop(3,"Top",400));
             h.add(new Shop(4,"Pant",124)); 
             h.add(new Shop(5,null,234));
        System.out.println("adding details:"+h);
        // find size of list
        System.out.println("size of the collection:"+h.size());
        
        //clone the list
        HashSet<Shop> cloned_list= new HashSet<Shop>(h);

        System.out.println("copy of the collection:"+cloned_list);
        
        // print first product detail
        Shop firstEle = h.stream().findFirst().get();
        
        // Print First element of HashSet
        System.out.println("First element of HashSet : "+ firstEle);
        
       }
       catch(Exception e) {
    	   System.out.println(e);
       }
       
	}

}

package com.yash.collection;

public class HealthCheckup {
	public static void main (String args[]) {
		
	} 
	

}

package com.yash.collection;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

class Shooping2 {
	int id;
	String name;
	int price;

public Shooping2(int id ,String name  ,int price) {
	this.id=id;
	this.name=name;
	this.price=price;
}

public void display() {
    System.out.println(this.id + "\t" + this.name + "\t" + this.price);
  }

}
public class Shooping1{
	public static void main(String args[]) {
		 
		HashSet<Shooping2> h=new HashSet<>();
		try{h.add(new Shooping2(1,"jhon",125));
		h.add(new Shooping2(2,"jhon",124));
		h.add(new Shooping2(3,"Aman",240));
		//provide null value
		h.add(new Shooping2(4,null,345));
		
		//find size of list
		System.out.println("size of list:"+h.size());
		for(Shooping2 c:h) {
			System.out.println(c.id+" "+c.name+" "+c.price);
				
			}
		HashSet<Shooping2> copyOfSet = new HashSet<Shooping2>(h);
		System.out.println("Copy HashSet: " + copyOfSet);
		
		
		
		}	catch(Exception e) {
			System.out.println(e);
		}
			
		}

}

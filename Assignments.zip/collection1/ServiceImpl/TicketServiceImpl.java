package com.yash.ServiceImpl;
import java.util.Iterator;
import java.util.Stack;
import java.util.Vector;

import com.yash.Service.TicketService;
import com.yash.model.StudentList;
import com.yash.model.TicketList;
import com.yash.model.Coustmer;


public class TicketServiceImpl implements TicketService{
	
	public static Vector<TicketList> createListofticket(){
		
		Vector<TicketList> vec = new Vector<TicketList>(); 
		 vec.add(new TicketList(1,"jhon",12,"pune"));  
	     vec.add(new TicketList(2,"smith",15,"mumbai"));  
	     vec.add(new TicketList(3,"andrew",18,"westBangal"));
		
		
		return vec;
	}	
	public static Stack<Coustmer> createListofcoustmer1(){
		Stack<Coustmer> stack = new Stack<Coustmer>();
	    stack.push(new Coustmer(1,"smith"));
	    stack.push(new Coustmer(2,"andrew"));
	    stack.push(new Coustmer(3,"aderson"));
	    stack.push(new Coustmer(4,"jhon"));
	    stack.push(new Coustmer(5,"andy"));
		return stack;	
	}
	
	@Override
	public void getAllTicket() {
		// TODO Auto-generated method stub
		Vector<TicketList>list=createListofticket();
		System.out.println(list);
		
		Iterator value = list.iterator();
		  
        // Displaying the values after iterating through the iterator
        System.out.println("The iterator values are: ");
        while (value.hasNext()) {
            System.out.println(value.next());
            
         
        }
      //first day of booking  
        System.out.println("The first day of booking = "+list.firstElement());
        
        // last day of booking
      //first day of booking  
        System.out.println("The last day of booking = "+list.lastElement());
        
      // remove first day of booking  
        System.out.println("remove first day booking is = "+list.remove(1));
	
        //size of the booked ticket
        System.out.println("remove first day booking is = "+list.size());
	

		Stack<Coustmer>list1=createListofcoustmer1();
		System.out.println("list of coustmer is:"  +list1);
		
		Iterator value1 = list1.iterator();
		  
        // Displaying the values after iterating through the iterator
        System.out.println("The iterator values are: ");
        while (value1.hasNext()) {
            System.out.println(value1.next());}
        
        
        
	}

	@Override
	public void getTicketByName() {
		
		}
	
	

}

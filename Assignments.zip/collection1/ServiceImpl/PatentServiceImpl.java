package com.yash.ServiceImpl;
import java.awt.List;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.yash.Service.PatentService;
import com.yash.model.PatentList;
public class PatentServiceImpl implements PatentService{
	public static Set<PatentList> createListofpatent(){
		
		Set<PatentList> h = new HashSet<PatentList>();
		h.add(new PatentList("jhon",12321423,"lungs"));
		h.add(new PatentList("sam",345321423,"kideny"));
		h.add(new PatentList("andrew",134321423,"leaver"));
		h.add(new PatentList("block",124341423,"brain"));
	   
		return h;
	}

	@Override
	public void getAllPatent() {
		Set<PatentList>list=createListofpatent();
		System.out.println(list);
		 
		Iterator value = list.iterator();
		  
	        // Displaying the values after iterating through the iterator
	        System.out.println("The iterator values are: ");
	        while (value.hasNext()) {
	            System.out.println(value.next());
	        }
	        PatentList firstEle = list.stream().findFirst().get();
	        
	        // Print HashSet
	        System.out.println("HashSet : " + list);
	 
	        // Print First element of HashSet
	        System.out.println("First element of HashSet : "+ firstEle);
	         //five record of patent
	        
	        
	}

	@Override
	public void getPatentByName() {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void getPatentByMobileno() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getPatentByDiease() {
		// TODO Auto-generated method stub
		
	}

}

package com.yash.ServiceImpl;

import java.util.Iterator;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
import com.yash.Service.StudentService;
import com.yash.model.PatentList;
import com.yash.model.StudentList;
public class StudentserviceImpl implements StudentService{
	public static Vector<StudentList> createListofstudent(){
	
	 Vector<StudentList> vec = new Vector<StudentList>(); 
	 vec.add(new StudentList(1,"jhon",12));  
     vec.add(new StudentList(2,"smith",10));  
     vec.add(new StudentList(3,"andrew",11));
     vec.add(new StudentList(4,"janny",9));
     vec.add(new StudentList(5,"stanly",12));
     
    return vec;
	}
    public static Stack<StudentList> createListofstudent1(){
	Stack<StudentList> stack = new Stack<StudentList>();
    stack.push(new StudentList(1,"smith",11));
    stack.push(new StudentList(2,"jhon",12));
    stack.push(new StudentList(3,"kendla",10));
    System.out.println("Stack elements:");
    return stack;
 
    }
	



	@Override
	public void getAllStudent() {
		// TODO Auto-generated method stub
		Vector<StudentList>list=createListofstudent();
		System.out.println(list);
		 //Check size and capacity  
        System.out.println("Size is: "+list.size());  
        System.out.println("Default capacity is: "+list.capacity());  
        
        
		
		Iterator value = list.iterator();
		  
        // Displaying the values after iterating through the iterator
        System.out.println("The iterator values are: ");
        while (value.hasNext()) {
            System.out.println(value.next());
            
            
        }
      //Checking if value is present or not in this vector         
        if(list.contains("1"))  
        {  
           System.out.println("jhon is present at the index " +list.indexOf("1"));  
        }  
        else  
        {  
           System.out.println("jhon is not present in the list.");  
        }  
        System.out.println("The first student of the vector is = "+list.firstElement());   
       
    //
     		Stack<StudentList>list1=createListofstudent1();
     		System.out.println(list1);
     		
     		Iterator value1 = list1.iterator();
  		  
            // Displaying the values after iterating through the iterator
            System.out.println("The iterator values of stack are: ");
            while (value1.hasNext()) {
                System.out.println(value1.next());}
            //Check size and capacity  
            System.out.println("Size is: "+list1.size());  
            System.out.println("Default capacity is: "+list1.capacity());  
            
        
	}

	@Override
	public void getStudentByName() {
		// TODO Auto-generated method stub
		
	}
}

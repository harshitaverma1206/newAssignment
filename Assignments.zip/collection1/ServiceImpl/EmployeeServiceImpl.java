package com.yash.ServiceImpl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.yash.Service.EmployeeService;
import com.yash.model.EmployeeList;


import java.util.HashMap;
public class EmployeeServiceImpl implements EmployeeService {
	
	public static HashMap<EmployeeList>createListofemployee(){ 
		
		

	    System.out.println("Initial HashMap: " + numbers);
	    // put() method to add elements
	    numbers.put(new EmployeeList(1,"jhon",1234,"sfd","cs"));
	    numbers.put("name", 2);
	    numbers.put("designation", 3);
	    numbers.put("department",4);
	    numbers.put("address",4);  
	    System.out.println("HashMap after put(): " + numbers);
	  return numbers;
}

		
	@Override
	public void getAllEmployee() {
		// TODO Auto-generated method stub
		Set<EmployeeRecord>list=(Set<EmployeeRecord>) createListofEmployee();
		System.out.println(list);
		 
		Iterator value = list.iterator();
		  
	        // Displaying the values after iterating through the iterator
	        System.out.println("The iterator values are: ");
	        while (value.hasNext()) {
	            System.out.println(value.next());
	        }
	        EmployeeRecord firstEle = list.stream().findFirst().get();
	        
	        // Print HashSet
	        System.out.println("HashSet : " + list);
	 
	        // Print First element of HashSet
	        System.out.println("First element of HashSet : "+ firstEle);
	         //five record of patent
	        
	        
	}

	

	


	@Override
	public void getEmployeeById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getEmployeeByName() {
		// TODO Auto-generated method stub
		
	}

}

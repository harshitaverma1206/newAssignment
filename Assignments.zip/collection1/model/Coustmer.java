package com.yash.model;

public class Coustmer {
	int id;
	String name;
	
	 public Coustmer(int id, String name) {
		// TODO Auto-generated constructor stub
		 super();
		 this.id=id;
		 this.name=name;
		 
	}
	public String toString() {
			return "student[ id=" + id + ",name=" + name +"]";
		}
}

package com.yash.model;

public class StudentList {
	int id;
	String name;
	int standard;
 public StudentList(int id,String name,int standard) {
	 super();
	 this.id=id;
	 this.name=name;
	 this.standard=standard;
 }
 public String toString() {
		return "student[ id=" + id + ",name=" + name +",standard="+standard+"]";
	}

}

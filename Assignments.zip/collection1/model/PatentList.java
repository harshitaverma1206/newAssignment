package com.yash.model;

public class PatentList {
	String name;
	int mobileno;
	String disease;
 public PatentList(String name,int mobileno,String disease) {
	 super();
	 this.name=name;
	 this.mobileno=mobileno;
	 this.disease=disease;
 }
 public String toString() {
		return "patent[name=" + name +",mobileno="+mobileno+",disease="+disease+"]";
	}

}
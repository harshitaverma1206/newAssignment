package com.yash.model;

public class EmployeeList {
	int id;
	String name;
	int  salary;
	String designation;
	String department;
 public EmployeeList(int id ,String name,int salary,String designation,String department) {
	 super();
	 this.id=id;
	 this.name=name;
	 this.salary=salary;
	 this.designation=designation;
	 this.department=department;
 }
 public String toString() {
		return "patent[ id=" + id + ",name=" + name +",salary="+salary+",designation="+designation+",department="+department+"]";
	}

}


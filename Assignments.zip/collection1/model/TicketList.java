package com.yash.model;

public class TicketList {
	int number;
	String name;
	int bookingdate;
	String city;
 public TicketList(int number,String name,int bookingdate,String city) {
	 super();
	 this.number=number;
	 this.name=name;
	 this.bookingdate=bookingdate;
	 this.city=city;
 }
 public String toString() {
		return "Ticket[number="+ number+ ",name=" + name +",bookingdate=" +bookingdate+ ",city=" +city+"]";
	}


}

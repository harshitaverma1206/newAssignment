package com.yash.MainApp;

import com.yash.ServiceImpl.EmployeeServiceImpl;
public class EmployeeMain {
	public static void main(String args[]) {
		EmployeeServiceImpl e=new EmployeeServiceImpl();
		e. getAllEmployee();
	}

}

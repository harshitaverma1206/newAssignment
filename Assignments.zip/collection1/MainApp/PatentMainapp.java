package com.yash.MainApp;
import com.yash.ServiceImpl.PatentServiceImpl;
public class PatentMainapp {
  public static void main(String args[]) {
	  PatentServiceImpl p=new PatentServiceImpl();
	  p.getAllPatent();	
	 
  } 
}

package com.yash.MainApp;
import com.yash.ServiceImpl.StudentserviceImpl;
public class StudentMain {
	public static void main(String args[]) {
	StudentserviceImpl s=new StudentserviceImpl();
	  s.getAllStudent();	
}
}
package com.yash.MainApp;

import com.yash.ServiceImpl.TicketServiceImpl;

public class TicketMain {
	public static void main(String args[]) {
		TicketServiceImpl s=new TicketServiceImpl();
		  s.getAllTicket();	
		  
	}
}

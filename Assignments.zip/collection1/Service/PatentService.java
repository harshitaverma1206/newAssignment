package com.yash.Service;

public interface PatentService {
	public void getAllPatent();
	public void getPatentByName();
	public void getPatentByMobileno();
	public void getPatentByDiease();

}

package com.yash.Service;

public interface StudentService {
	public void getAllStudent();
	public void getStudentByName();
}

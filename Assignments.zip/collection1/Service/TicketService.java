package com.yash.Service;

public interface TicketService {
	public void getAllTicket();
	public void getTicketByName();
	public void createListofcoustmer();
	
}

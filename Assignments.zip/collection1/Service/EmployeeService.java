package com.yash.Service;

public interface EmployeeService {
	public void getAllEmployee();
	public void getEmployeeById();
	public void getEmployeeByName();
}

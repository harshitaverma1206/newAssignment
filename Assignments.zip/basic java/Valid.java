class  Valid{
    public static void main(String args[]) { 
    	String name="harshita";
    	String city="indore";
    	String address=new String("indore");
        System.out.println(name+ " " +city+ " " +address);
        String s1="india";
        String s2="japan";
        String S3="china";
        System.out.println(s1.length());
    }      
}
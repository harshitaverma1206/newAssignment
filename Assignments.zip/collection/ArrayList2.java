package com.yash.collection;
import java.util.ArrayList;
public class ArrayList2 {
	 public static void main(String[] args){
	        ArrayList<String> animals = new ArrayList<>();
	        // Add methods elements 
	        animals.add("Dog");
	        animals.add("Cat");
	        animals.add("Horse");
	        System.out.println("ArrayList: " + animals);
	        //Add front method
	        animals.add(0, "hat");
	        animals.add(1, "goat");
	        System.out.println("ArrayList after adding elements at the beginning:");
	        //print ArrayList
	        System.out.println(animals);

	        
	    }

}

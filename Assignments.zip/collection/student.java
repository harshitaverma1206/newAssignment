package com.yash.collection;

public class student {
	int id;
	String name;
	
	
public student(int id,String name) {
	super();
	this.id=id;
	this.name=name;
	
	
}
public String toString() {
	return "Student[id=" + id +",name="+ name +"]";
}
	
}

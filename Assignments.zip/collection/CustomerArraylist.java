package com.yash.collection;
import java.util.ArrayList;
public class CustomerArraylist {
}
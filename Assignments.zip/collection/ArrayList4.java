package com.yash.collection;

import java.util.ArrayList;
//using contains methods
public class ArrayList4 {
	public static void main(String args[]) {
		ArrayList<String> colorsList = new ArrayList<String>();
		colorsList.add("red");
		colorsList.add("yellow");
		colorsList.add("green");
		colorsList.add("blue");
		colorsList.add("brown");
		System.out.println("array list are:"+colorsList);
		System.out.println("size of list:"+colorsList.size());
		
		//contains method to check if different strings are present in ArrayList 
		System.out.println("ArrayList contains ('Red Green'): "
                +colorsList.contains("Red Green"));
        System.out.println("ArrayList contains ('blue'): "
                  +colorsList.contains("blue"));
        System.out.println("ArrayList contains ('white'): "
                +colorsList.contains("white"));
        

	}

}

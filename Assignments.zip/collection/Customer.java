package com.yash.collection;

import java.util.ArrayList;
import java.util.Arrays;

public class Customer {
	public static void main(String []args) {
		ArrayList<String> customerList=new ArrayList<>();
		customerList.add("name");
		customerList.add("id");
		customerList.add("quantity");
		System.out.println(customerList);
		}

}

package com.yash.collection;

import java.util.ArrayList;
import java.util.Arrays;
//using clear() and is empty()
public class ArrayList6 {
	public static void main(String args[]) {
		ArrayList<String> monthList=new ArrayList<String>(Arrays.asList("january","fabuary","march","april"));
    System.out.println("list is:"+monthList);
// using clear()
    monthList.clear();
    System.out.println("list is after clear:"+monthList);
    // check list is empty or not
    System.out.println(" check list is empty or not :"+monthList.isEmpty());
	}
}
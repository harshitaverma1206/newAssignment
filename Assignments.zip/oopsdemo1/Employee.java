package com.yash.oopsdemo1;

class Employee {
	default int id=12;
	String name;}
	
 
}

class Employeeapp extends Employee{
	public static void main(String args[]) {
	
	
	}
	}

		
		 
		 
		
		
	


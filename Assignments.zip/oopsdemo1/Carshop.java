package com.yash.oopsdemo1;

public class Carshop {
	int speed;
	String owner;
	String type;
	public int getSpeed() {

	      return speed;
			
		}
		public void setSpeed(int speed) {
	        this.speed = speed;
	}
		public String getOwner() {

		      return owner;
				
			}
			public void setOwner(String owner) {
		        this.owner = owner;
		}		
			public String getType() {

			      return type;
					
				}
				public void setType(String type) {
			        this.type = type;
			}	
		


public static void main(String args[]) {
	
	Carshop obj=new Carshop();
	obj.setSpeed(123);
    obj.setOwner("jhon");
    obj.setType("honda");
   
   System.out.println("Speed:" +obj.getSpeed());
   System.out.println("Owner:" +obj.getOwner());
   System.out.println("Type:" +obj.getType());
   int a=10;
   System.out.println("no. of cars sold by carshop:"+a);
   
}
}

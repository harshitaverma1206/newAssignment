package com.yash.FileDemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
//copy data of one file into another 	  
	public class FileDemo1 {
	    
		 public static void main(String[] args) {
		      FileInputStream ins = null;
		      FileOutputStream outs = null;
		      try {
		         File infile = new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\file2.txt");
		         File outfile = new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\file2.txt");
		         ins = new FileInputStream(infile);
		         outs = new FileOutputStream(outfile);
		         byte[] buffer = new byte[1024];
		         int length;
		         
		         while ((length = ins.read(buffer)) > 0) {
		            outs.write(buffer, 0, length);
		         } 
		         ins.close();
		         outs.close();
		         System.out.println("File copied successfully!!");
		      } catch(IOException ioe) {
		         ioe.printStackTrace();
		      } 
		   }
		}
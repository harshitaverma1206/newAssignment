package com.yash.FileDemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileDemo8 {
	public static void main(String args[]) throws IOException {
	try{File f=new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\doc3.txt");
	FileInputStream fin=new FileInputStream(f);
	byte file_content[] = new byte[2*1024];
    int read_count = 0;
    while((read_count = fin.read(file_content)) > 0){
        System.out.println(new String(file_content, 0, read_count-1));
    }
} 
  catch (FileNotFoundException e) {
    e.printStackTrace();
} catch (IOException e) {
    e.printStackTrace();
} 
	
}
}

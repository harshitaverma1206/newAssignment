package com.yash.reflection;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}

public int getid(int id) {
	  return id;
}
public void setid(int id) {
	  this.id=id;
}
public String getName(String name) {
	  return name;
}
public void setName(String name) {
	  this.name=name;
}

public static void main(String args[]) {

Employee obj= new Employee();

  obj.setid(12);
  obj.setName("jhon");
  
  

 System.out.println(obj.getid(12));
 System.out.println(obj.getName("jhon"));
 
 
}     
}



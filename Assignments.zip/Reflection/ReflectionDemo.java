package com.yash.reflection;

import java.lang.reflect.Modifier; 

public class ReflectionDemo {
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException {
		
		Class c=Class.forName("com.yash.reflection.Employee");
		System.out.println(c);
		
		// find superclass
		System.out.println("super Class:"+c.getSuperclass());
		
		int mod = c.getModifiers();
		// returns 0 when Employee class is not available
		//returns 1 when Employee class is available
		
		System.out.println("mod:"+mod);
		
		//find Access modifier
		System.out.println("Access modifier:"  +Modifier.toString(mod));
		
		// check Primitive or not
		System.out.println("check:"+c.isPrimitive());
		
		//find constructor
		System.out.println("constructor:"+c.getConstructor());
		
		System.out.println("class:"+c.getClass());
		
		//find Interfaces 
		Class[] classes =c.getInterfaces();
		for(Class cls : classes)
		System.out.println(cls+"hashcode"  +cls.hashCode());
		
	
	}

}

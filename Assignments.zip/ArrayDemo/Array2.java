package com.yash.arraydemo.util;

public class Array2 {

	public static void main(String[] args) {
		int a[]= {33,45,5};
		int i;
		for(i=0;i<a.length;i++)
		System.out.println(a[i]);
		

	}

}

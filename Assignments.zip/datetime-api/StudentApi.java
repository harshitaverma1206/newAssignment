package com.yash.APi;

import java.util.ArrayList;
import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class StudentApi1 {
	String name;
	String section;
	int percentage;
	String result;
	
public StudentApi1(String name,String section,int percentage,String result) {
	super();
	this.name=name;
	this.section=section;
	this.percentage=percentage;
	this.result=result;
}	
public String toString() {
	return "Student[ name=" + name +",section="+section+",percentage="+percentage+",result="+result+"]";
}
public static void DateTime() {
	//shows time
	LocalDate date = LocalDate.now();
    System.out.println("the current date is "+date);
    
    //show current time
    LocalDateTime current = LocalDateTime.now();
    System.out.println("current date and time : "+current);
    
    // printing some specified date
    LocalDate d = LocalDate.of(2018,10,2);
    System.out.println("the gandhijayanti day  :"+d);
}


}
public class StudentApi{
	 public static void main(String[] args) { 
		 //inserting student data in set
	List<StudentApi1> s = new ArrayList<StudentApi1>();
	s.add(new StudentApi1("Andy","B",40,"pass"));
	s.add(new StudentApi1("Anand","A",75,"pass"));
	s.add(new StudentApi1("sumedh","B",30,"fail"));
	s.add(new StudentApi1("Anjel","C",65,"pass"));
	
	//print student
	//System.out.println("student record are:"+s);
	
	//iterating the student list
	//Iterator value = s.iterator();
	  //    System.out.println("The iterator values are: ");
    //while (value.hasNext()) {
      //  System.out.println(value.next());
       
	
	//limit is used to print the first number(limit is intermediate operation)
    List<StudentApi1>  c= s.stream()
            .limit(2)
           .collect(toList());//(terminal operation) collect() uses the toList() method to return a list equivalent of the stream
     c.forEach(System.out::println);//loop is print all elements in the c 
     
     // print less percentage student 
     List<Integer> p=s.stream()
    		 .filter(m -> m.percentage < 60)
    		 .map(m->m.percentage)
    		 .collect(Collectors.toList());
     System.out.println("less percentage is:"+p);
    
     //name of student
     List<String> r=s.stream()
    		 .filter(o -> o.name.length()>3)
    		 .map(o->o.name)
    		 .collect(Collectors.toList());
     System.out.println("name of student is:"+r);
     
     
    		 
     
         
     StudentApi1 a=new StudentApi1(null, null, 0, null);
     a.DateTime();
     
          }
    
}
	 

package com.yash.Exception;

public class Exception2 {
	public static void main (String args[]) {
		try{int a=5;
		int b=0;
		int c=a/b;//a is not divide by 0
    System.out.println(c);}
    catch(ArithmeticException e) { 
        System.out.println ("Can't divide a number by 0");
    }
	
	 
	 
	}
}

package com.yash.Exception;
import java.util.*;
 class Text  {
	public static void convertStringToFloat(String str) throws Exception{ 
		float floatValue;
		  
        
            floatValue = Float.parseFloat(str);
  
            // Print the expected float value
         System.out.println(str+ " after converting into float = "+ floatValue);   
        throw new Exception("exception"); 
        }
        
	
        // Driver code
    public static void main(String[] args) throws Exception
    {
  
        // The string value
        String str1 = "";
        String str2 = null;
        String str3 = "GFG";
  
        // Convert string to float
        // using parseFloat() method
        convertStringToFloat(str1);
        convertStringToFloat(str2);
        convertStringToFloat(str3);
    }
}
		
	    

package com.yash.Exception;

import java.util.ArrayList;
import java.util.*;
public class ProductApp2 {
	public static void main (String args[]) {
		 
	int id;
	String name;
	double price;
	String color;
	
	try{
		ArrayList<String> str = new ArrayList<String>();
	       
	       if(str.isEmpty()) {
	            System.out.println("ArrayList is empty.");
	        } else {
	            System.out.println("ArrayList is not empty.");
	       System.out.println("ArrayList : " + str);
	        }}
       catch(Exception e){
    	   System.out.println("e");
       }
	}
}
		 
	 
	
	        



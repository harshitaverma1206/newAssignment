package com.yash.Exception;
import java.util.Scanner;
public class Text1 {
	public static void main(String[] args)  {
		
		try{
			int num=Integer.parseInt("harshita");
		System.out.println(":"+num);
		
			
	
	Scanner sc= new Scanner(System.in); //System.in is a standard input stream  
	System.out.println("Enter a input: ");  
	String str= sc.nextLine();}   
    
	
	catch(NumberFormatException e) {
		System.out.println("NumberFormatException");
	}
		}
}



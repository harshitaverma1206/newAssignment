package com.yash.Exception;

public class Double {
	public static void parseDouble() throws Exception{
		try{String decimal = "100.25";  
		float f = Float.parseFloat(decimal); 
		System.out.println("float equvialent of String " + decimal + " is : " + f);
		f = Float.parseFloat("200"); System.out.println("String 200 in float is : " + f);

		}
		catch(Exception e){
			System.out.println(e);
		}
	} 
public static void main(String args[]) throws Exception {
	parseDouble();
}		
	

}

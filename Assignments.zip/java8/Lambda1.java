package com.yash.java8;
// using double parameter
interface demo2{
	public  void showAdd(int num1,int num2);
}

public class Lambda1 {
  public static void main(String args[]) {
	  //reference creating
	  demo2 d=(num1,num2)->{
		  System.out.println("the addition is:"  +(num1+num2));
		  System.out.println("the multiplication is:"  +(num1*num2));
		  System.out.println("the division is:"  +(num1/num2));
	  };
	  d.showAdd(20,30);
  }
}

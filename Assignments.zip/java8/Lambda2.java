package com.yash.java8;
// no parameter

interface demo3{
	public String noPara();
}
public class Lambda2 {
	public static void main(String[] args) { 
		//reference creating
		demo3 d=()->{
			return "no parameter here.";
		};
		 System.out.println(d.noPara());  
	}
}

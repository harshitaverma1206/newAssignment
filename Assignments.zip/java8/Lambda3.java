package com.yash.java8;
//lambda expression with thread
public class Lambda3 {

	 public static void main(String[] args) {  
		 Runnable r2=()->{  
             System.out.println("Thread2 is running...");  
     };  
     Thread t2=new Thread(r2);  
     t2.start();  
	 }
}

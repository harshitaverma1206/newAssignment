package com.yash.java8;

interface Demo{
	public void showID();
	
	default void add() {
		System.out.println("this is show");
	}	
	default void sub(){
		
	System.out.println("this is sub");
	}
	default void multi() {
		System.out.println("this is div");
	}

	 static void showName() {
		// TODO Auto-generated method stub
		System.out.println("satatic method");
	}
}

public class Employee implements Demo{
  
	public static void main(String[]args) {
		Employee i=new Employee();
		i.showID();
		i.add();
		i.sub();
		i.multi();
		Demo.showName();
		i.showName();
	}
	
	public  void showName() {
		// TODO Auto-generated method stub
		System.out.println("this is static");
	}

	@Override
	public void showID() {
		// TODO Auto-generated method stub
		System.out.println("my id is 121");
	}
	public void add() {
		System.out.println("this is addition  :"  +(10+30));
	}
	public void  sub() {
		System.out.println("this is subtraction  :"  +(30-10));
	}
	public void  multi() {
		System.out.println("this is multiplication :"  +(30*10));
	}	

}

package com.yash.java8;
//single parameter
interface demo1{
	public void showMsg(int num);
}

public class Lambda {
	public static void main(String args[]) {
		//reference creating
		demo1 d=(num)->{
		System.out.println("it is showing:" +num);	
		};
	d.showMsg(20);
	}

}

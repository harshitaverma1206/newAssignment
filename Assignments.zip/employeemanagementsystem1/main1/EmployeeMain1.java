package com.yash.main1;
import com.yash.employeeserviceimpl1.EmployeeServiceImpl1;
import com.yash.model1.EmployeeModel;
/**
 * This is a main class to provide record of employee
 *
 * @author harshita
 */
public class EmployeeMain1 {
	 static EmployeeModel er[]=new EmployeeModel[5];
	    public static void main(String[] args) {
	    	EmployeeServiceImpl1 f=new EmployeeServiceImpl1();
			f.getAllEmployee1();
			f.getmenu();
			f.goodBaye();
    }	
 }



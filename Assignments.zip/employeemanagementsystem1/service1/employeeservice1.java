package com.yash.service1;
/**
 * This is a service class to provide methods  for  employee record
 *
 * @author harshita
 */
public interface employeeservice1 {
	public void getAllEmployee1();
	public void goodBaye();
	public void getmenu();
	public void getEmployeeById();
	public void getEmployeeByName();
	public void getEmployeeBySalary();
	public void getEmployeeByCity();
	public void getEmployeeByDepartment();
	public void getHighestSalary();
	public void getMinimumSalary();
	


}

package com.yash.oopsdemo2;

public class BankBalance {
	

	    private static final Object SavingAccount = null;

		public static void main(String[] args) {
	        Account[] accounts = new Account[2];
	        accounts[0] = new SavingAccount(2, 0.25);
	        accounts[1] = new CourrentAccount(23, 50);

	        for(int i=0; i<accounts.length;i++) {
	            if (accounts[0].equals(SavingAccount))
	                System.out.println(accounts[0].getInterest());
	        }
	    }

}

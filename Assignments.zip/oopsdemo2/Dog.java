package com.yash.oopsdemo2;
//using inheritance
public class Dog {
	 public static void main(String args[]) {
		    System.out.println("dog can speak");
	}
	}
	  
class Labrador extends Dog{
	
	String name;
	String color;
	public String getName() {
		return  name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getColor() {
		return  color;
	}
	public void setColor( String color) {
		this.color=color;
	}}

class Yorkshire extends Dog{
	public static void averagebreed() {
		// TODO Auto-generated method stub
		int weight=12;
		System.out.println("Weight:" +weight);
		}
	}

		
			
		
	

	
	





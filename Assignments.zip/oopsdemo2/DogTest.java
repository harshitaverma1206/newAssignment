package com.yash.oopsdemo2;

public class DogTest extends Labrador {
	public static void main(String [] args) {
	Labrador obj= new Labrador();
	obj.setName("puppy");
    obj.setColor("brown");
   System.out.println("Name:" +obj.getName());
   System.out.println("Color:" +obj.getColor());
   System.out.println("dogs are speaks");

	}}

 


	

	



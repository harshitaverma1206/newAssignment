package com.yash.oopsdemo2;

public class Bank {
   void getbalance() {
	 int i=0;
	 
	 System.out.println("bank return:"+i);
	 }
 class Sbi extends Bank {
 void getbalance1() {
	 int j=1500;
	System.out.println("bank return:"+j);
 }
 }
			
public static void main(String args[]) {
	Bank b=new Bank();
	
	b.getbalance();
	
	
	
	
	
	
	
	
}}

	


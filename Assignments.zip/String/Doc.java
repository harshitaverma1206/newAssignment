
public class Doc {
	public static void main(String args[]) { 
		String title="hello";
		String filepath="jre";
	    System.out.println(title +" " + filepath);
	    System.out.println(title +" " + filepath);
	   
	      
package com.yash.multithreading1;

public class Product {

	static void getlistofProduct(String fname, int id) {
	    System.out.println(fname + " is " + id);
	  }

	  public static void main(String[] args) {
		  getlistofProduct("cell", 5);
		  getlistofProduct("tablet", 8);
		  getlistofProduct("phone", 31);
	  }
	}

	



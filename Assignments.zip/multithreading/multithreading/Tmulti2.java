package com.yash.multithreading;

public class Tmulti2 implements Runnable {
	int a=100;
	int b=200;
	int c,d,e,f;
	

public static void main(String[] args) {
	
	Tmulti2 obj = new Tmulti2();
	Thread t = new Thread(obj);
	t.start();
    System.out.println("This is addition,subtraction");
		  }
	
public void run() {
   try{
		System.out.println( "current thread:" +Thread.currentThread().getId());
			c=a+b;
			
		System.out.println("This code is running :"+c);
		    d=a-b;
		System.out.println("This code is running :"+d);
		    e=b/a;
		System.out.println("This code is running :"+e); 
		    f=a*b;
		System.out.println("This code is running :"+f);  
		
			}
	catch(Exception e) {
			System.out.println(e);
		}
 }
}
